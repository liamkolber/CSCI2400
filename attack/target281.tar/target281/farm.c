/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_246(unsigned x)
{
    return x + 3281162328U;
}

void setval_149(unsigned *p)
{
    *p = 2496104776U;
}

void setval_183(unsigned *p)
{
    *p = 3373712216U;
}

unsigned addval_477(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_331()
{
    return 3351742792U;
}

void setval_204(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_200()
{
    return 1691403096U;
}

unsigned getval_286()
{
    return 2425376998U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_345(unsigned x)
{
    return x + 2447411528U;
}

void setval_235(unsigned *p)
{
    *p = 3525886345U;
}

unsigned getval_128()
{
    return 3286272344U;
}

unsigned getval_275()
{
    return 3674786443U;
}

void setval_489(unsigned *p)
{
    *p = 3677929897U;
}

unsigned getval_396()
{
    return 3682910605U;
}

void setval_196(unsigned *p)
{
    *p = 3531921065U;
}

unsigned addval_361(unsigned x)
{
    return x + 3767093468U;
}

unsigned getval_244()
{
    return 3281043851U;
}

unsigned getval_257()
{
    return 3281049229U;
}

unsigned addval_310(unsigned x)
{
    return x + 3229925769U;
}

unsigned addval_311(unsigned x)
{
    return x + 3269495112U;
}

void setval_373(unsigned *p)
{
    *p = 2425473673U;
}

unsigned getval_371()
{
    return 3372799627U;
}

unsigned getval_248()
{
    return 3374372491U;
}

void setval_287(unsigned *p)
{
    *p = 3767093469U;
}

void setval_366(unsigned *p)
{
    *p = 2425411209U;
}

void setval_490(unsigned *p)
{
    *p = 348373385U;
}

unsigned getval_269()
{
    return 3374372489U;
}

unsigned addval_452(unsigned x)
{
    return x + 3674786457U;
}

void setval_114(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_199()
{
    return 3284830618U;
}

unsigned getval_468()
{
    return 3372796617U;
}

unsigned getval_364()
{
    return 3269495112U;
}

unsigned getval_346()
{
    return 3380134281U;
}

void setval_457(unsigned *p)
{
    *p = 3674789529U;
}

unsigned getval_268()
{
    return 3531915659U;
}

void setval_171(unsigned *p)
{
    *p = 3284830628U;
}

unsigned getval_316()
{
    return 3281177225U;
}

unsigned getval_445()
{
    return 3286272330U;
}

void setval_210(unsigned *p)
{
    *p = 3525888649U;
}

unsigned getval_485()
{
    return 3223901833U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
