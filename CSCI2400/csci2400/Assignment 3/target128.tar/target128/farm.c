/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_254(unsigned *p)
{
    *p = 3284633944U;
}

unsigned addval_318(unsigned x)
{
    return x + 2425394264U;
}

void setval_437(unsigned *p)
{
    *p = 3284638024U;
}

unsigned getval_283()
{
    return 2428995912U;
}

unsigned addval_402(unsigned x)
{
    return x + 3281096792U;
}

unsigned addval_494(unsigned x)
{
    return x + 3687026776U;
}

unsigned getval_353()
{
    return 2428995912U;
}

unsigned addval_172(unsigned x)
{
    return x + 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_398()
{
    return 2430634312U;
}

unsigned addval_493(unsigned x)
{
    return x + 2425474697U;
}

void setval_281(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_413(unsigned x)
{
    return x + 3221802633U;
}

unsigned getval_440()
{
    return 3685011081U;
}

unsigned addval_110(unsigned x)
{
    return x + 3281306249U;
}

void setval_209(unsigned *p)
{
    *p = 3526938241U;
}

void setval_192(unsigned *p)
{
    *p = 3525890441U;
}

unsigned addval_271(unsigned x)
{
    return x + 3374367385U;
}

unsigned getval_135()
{
    return 3286288712U;
}

unsigned addval_181(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_161()
{
    return 2425668233U;
}

void setval_149(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_215(unsigned x)
{
    return x + 3674784393U;
}

void setval_377(unsigned *p)
{
    *p = 3534016905U;
}

unsigned addval_422(unsigned x)
{
    return x + 3675832969U;
}

void setval_445(unsigned *p)
{
    *p = 2430634316U;
}

unsigned addval_372(unsigned x)
{
    return x + 3372798345U;
}

unsigned addval_187(unsigned x)
{
    return x + 4006071945U;
}

unsigned addval_171(unsigned x)
{
    return x + 3223372425U;
}

unsigned addval_303(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_343(unsigned x)
{
    return x + 2429462859U;
}

unsigned getval_134()
{
    return 3674260105U;
}

void setval_292(unsigned *p)
{
    *p = 3229143433U;
}

void setval_367(unsigned *p)
{
    *p = 3531915917U;
}

unsigned getval_131()
{
    return 3252717896U;
}

void setval_326(unsigned *p)
{
    *p = 3372797641U;
}

unsigned getval_409()
{
    return 2425409929U;
}

unsigned getval_428()
{
    return 3374895497U;
}

void setval_224(unsigned *p)
{
    *p = 2497743176U;
}

void setval_306(unsigned *p)
{
    *p = 3375943945U;
}

void setval_439(unsigned *p)
{
    *p = 2463205845U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
